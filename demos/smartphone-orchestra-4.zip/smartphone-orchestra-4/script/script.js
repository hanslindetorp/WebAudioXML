

const socket = io();
var noSleep = new NoSleep();

socket.on('connect', () => {
    socket.emit("addClient", window.navigator.userAgent);
});

socket.on('serverToClient', (msg) => {
    // document.querySelector(".output").innerHTML = `${msg.value || ""}`;



    switch(msg.command){

        case "midiIn":
        switch(msg.value.status){

            case 11:
            // controllers
            switch(msg.value.data1){
                case 74:
                    waxml.setVariable("padVolume", msg.value.data2);
                break;
            }
            break;
        }
        break;

        case "midinote":
            waxml.setVariable("key", msg.value.key);
            waxml.setVariable("padGate", msg.value.gain);
           

            let noteName = typeof msg.value.key == 'undefined' ? "" : ["C","C#","D","D#","E","F","F#","G","G#","A","Bb","B"][msg.value.key % 12];
            document.querySelector(".note-name").innerHTML = noteName;
        break;

        case "midinoteoff":
            waxml.setVariable("padGate", 0);
            document.querySelector(".note-name").innerHTML = "";
        break;

        case "filterControl":
            waxml.setVariable("filter", msg.value)
        break;

        case "midiController":
            waxml.setVariable("padVolume", msg.value)
        break;

        case "set-mode":
            window.location = `#${msg.value}`;
            switch(msg.value){
                case "solo":
                    waxml.setVariable("solo", 1);
                    waxml.setVariable("pad", 0);
                break;

                case "pad":
                    waxml.setVariable("solo", 0);
                    waxml.setVariable("pad", 1);
                break;
            }
        break;

        case "testNote":
            waxml.setVariable("testNote", msg.value);
            waxml.setVariable("testGate", 1);
            setTimeout(() => waxml.setVariable("testGate", 0), 50);
        break;
        
    }
});

waxml.addEventListener("inited", () => {


    document.querySelector("#initBtn").addEventListener("click", e => {
        document.body.style.touchAction = "none";
        waxml.init();
        noSleep.enable();
    });
    

    // window.location = "#solo";
    window.location = `#${document.querySelector("main > section").getAttribute("id")}`;

    // requestWakeLock();


});

// The wake lock sentinel.
let wakeLock = null;

// Function that attempts to request a screen wake lock.
const requestWakeLock = async () => {
    try {
        wakeLock = await navigator.wakeLock.request();
        wakeLock.addEventListener('release', () => {
            console.log('Screen Wake Lock released:', wakeLock.released);
            });
        console.log('Screen Wake Lock released:', wakeLock.released);
    } catch (err) {
        console.error(`${err.name}, ${err.message}`);
    }
}
